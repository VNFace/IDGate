from flask import Flask, request, redirect, render_template,send_from_directory,Response,jsonify,url_for
import threading
import sys
import os
import datetime
import time
from datetime import datetime,timedelta, date
import numpy as np
import jsonpickle
import cv2
import matplotlib.pyplot as plt
from shutil import rmtree,copyfile
import base64
import json

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
# initialize the output frame and a lock used to ensure thread-safe
lock = threading.Lock()

app = Flask(__name__)

@app.route("/people", methods=["GET"])
def getPeopl():
    from functions.sqlquery import sql_query,sql_query_export    
    results = sql_query(''' SELECT * FROM Employee_History ORDER  BY time DESC LIMIT 3''')
    ID_Emp_His = {}
    etime = {}
    FullName = {}
    image = {}
    
    id_emp = {}
    idx = 0
    confident = {}
    for row in results:
        etime[idx] = datetime.strptime(row["time"],"%Y-%m-%d %H:%M:%S")
        ID_Emp_His[idx] = row["ID_Emp_His"]        
        FullName[idx] = row["FullName"]        
        id_emp[idx] = row["ID_Emp"]
        confident[idx]= row["confident"]
        with open(row["url_history"], "rb") as img_file:
            image[idx] = base64.b64encode(img_file.read())
        idx = idx+1
    return jsonify(id_emp=id_emp,FullName=FullName,etime=etime,image=image,ID_Emp_His=ID_Emp_His)

#==========================================END=======================================================================
if __name__ == "__main__":
    app.run(host="0.0.0.0", port="5000",debug=True)

